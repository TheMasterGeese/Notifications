# Discord Integration

##  2.1.0
- Fixed issue with generating manifest/download urls
##  2.0.0
- Added sendDiscordMessage hook
##  1.0.0
- Discord Integraiton