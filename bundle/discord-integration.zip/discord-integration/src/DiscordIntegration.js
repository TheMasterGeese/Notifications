/* eslint-disable @typescript-eslint/ban-ts-comment */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
	function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
	return new (P || (P = Promise))(function (resolve, reject) {
		function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
		function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
		function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
		step((generator = generator.apply(thisArg, _arguments || [])).next());
	});
};
// TODO: Right now it isn't resolving types properly, thinks quite a few things are "any"
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
let gameUsers;
Hooks.once("ready", function () {
	gameUsers = game.users.contents;
});
Hooks.once("init", function () {
	// add settings option for URL of Discord Webhook
	console.log(game);
	game.settings.register("discord-integration", "discordWebhook", {
		name: game.i18n.localize("DISCORDINTEGRATION.SettingsDiscordWebhook"),
		hint: game.i18n.localize("DISCORDINTEGRATION.SettingsDiscordWebhookHint"),
		scope: "world",
		config: true,
		type: String,
		default: "",
	});
});
// add in the extra field for DiscordID
Hooks.on("renderUserConfig", function (config, element) {
	return __awaiter(this, void 0, void 0, function* () {
		// find the user that you're opening config for
		const foundryUser = gameUsers.filter((user) => { return user.id === config.object.data._id; })[0];
		// get their Discord ID if it exists
		let discordUserId = yield foundryUser.getFlag('discord-integration', 'discordID');
		discordUserId = discordUserId ? discordUserId : "";
		// create the input field to configure it.
		const input = `<input type="text" name="discord-id-config" value="${discordUserId}" data-dtype="String">`;
		// Put the input field below the "Player Color group" field.
		const playerColorGroup = element.find('.form-group').eq(2);
		playerColorGroup.after($(`
				<div class="form-group discord">
					<label>${game.i18n.localize("DISCORDINTEGRATION.UserDiscordIdLabel")}</label>
					${input}
				</div>
			`));
	});
});
// commit any changes to userConfig
Hooks.on("closeUserConfig", function (config, element) {
	return __awaiter(this, void 0, void 0, function* () {
		// find the user that the config was open for
		const foundryUser = gameUsers.filter(user => { return user.id === config.object.data._id; })[0];
		// get the value of the discord id field.
		// TODO investigating
		// @ts-ignore
		const discordID = element.find("input[name = 'discord-id-config']")[0].value;
		// update the flag
		yield foundryUser.update({ 'flags.discord-integration.discordID': discordID });
	});
});
/**
* To forward a message to discord, do one of two things:
*
* -include "@<username>" for a user in the game, it will then look up the corresponding discordID
* and send a message pinging them. If you @ multiple people, it will ping all of them. Will not
* send a message unless the username matches up with an actual user.
*
* -include "@Discord", which will unconditionally forward the message (minus the @Discord) to the Discord Webhook.
*
*/
// whenever someone sends a chat message, if it is marked up properly forward it to Discord.
Hooks.on("chatMessage", function (chatLog, message) {
	sendDiscordMessage(message).catch((reason) => {
		console.error(reason);
	});
});
Hooks.on("sendDiscordMessage", function (message) {
	sendDiscordMessage(message).catch((reason) => {
		console.error(reason);
	});
});
/**
* Sends a message through the discord webhook as configured in settings.
*
* Messages that ping users in Discord need to have "@<gameUserName>" and the users must have their discord IDs configured.
*
* @param message The message to forward to Discord
*/
export function sendDiscordMessage(message) {
	return __awaiter(this, void 0, void 0, function* () {
		// search for any @<username> strings in the message
		const userNames = gameUsers.map((user) => { return user.name; }); // get a list of usernames
		const usersToPing = [];
		userNames.forEach((userName) => {
			if (message.indexOf(`@${userName}`) !== -1) {
				usersToPing.push(userName);
			}
		});
		// search for @Discord in the message
		const shouldPingDiscord = (message.search(`@Discord`) !== -1);
		// if it found any @<username> values, replace the values in the message with appropriate discord pings, then send discord message.
		if (usersToPing.length !== 0) {
			usersToPing.forEach((userName) => {
				const currentUser = gameUsers.filter((user) => { return user.data.name === userName; })[0];
				if (currentUser) {
					const currentUserDiscordID = currentUser.getFlag('discord-integration', 'discordID');
					message = message.replace(`@${userName}`, `<@${currentUserDiscordID}>`);
				}
			});
			// else if Discord as a whole is being pinged, remove the "@Discord" part and then send the message.
		}
		else if (shouldPingDiscord) {
			message = message.split("@Discord").pop() || "";
		}
		const messageJSON = {
			"content": message
		};
		yield $.ajax({
			method: 'POST',
			url: game.settings.get('discord-integration', 'discordWebhook'),
			contentType: "application/json",
			data: JSON.stringify(messageJSON)
		});
	});
}
